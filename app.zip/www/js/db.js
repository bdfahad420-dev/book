const DB = (() => {
  let db;
  const rq = r => new Promise((res, rej) => { r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
  const open = () => new Promise((res, rej) => {
    const r = indexedDB.open('boighor', 1);
    r.onupgradeneeded = e => {
      const d = e.target.result;
      d.createObjectStore('books', { keyPath: 'id' });
      d.createObjectStore('files', { keyPath: 'id' });
      d.createObjectStore('annots', { keyPath: 'id' });
    };
    r.onsuccess = () => { db = r.result; res(); };
    r.onerror = () => rej(r.error);
  });
  const st = (n, m = 'readonly') => db.transaction(n, m).objectStore(n);
  const done = t => new Promise((res, rej) => { t.oncomplete = res; t.onerror = () => rej(t.error); t.onabort = () => rej(t.error); });
  return {
    open,
    all: n => rq(st(n).getAll()),
    get: (n, id) => rq(st(n).get(id)),
    put: (n, o) => rq(st(n, 'readwrite').put(o)),
    del: (n, id) => rq(st(n, 'readwrite').delete(id)),
    async delMany(n, ids) {
      const t = db.transaction(n, 'readwrite');
      ids.forEach(id => t.objectStore(n).delete(id));
      return done(t);
    }
  };
})();
