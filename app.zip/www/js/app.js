const TABS = ['library', 'favs', 'notes', 'settings'];

const App = {
  jump: null,
  openBook(id, jump) { App.jump = jump || null; location.hash = '#/read/' + id; },
  go(tab) { location.replace('#/' + tab); },
  renderAll() { Lib.render(); Notes.render(); Settings.render(); }
};

function showTab(tab) {
  $$('.view').forEach(v => v.classList.toggle('on', v.id === 'v-' + tab));
  $$('#tabbar button').forEach(b => b.classList.toggle('on', b.dataset.tab === tab));
  if (tab === 'library' || tab === 'favs') Lib.render();
  if (tab === 'notes') Notes.render();
}

function route() {
  const h = location.hash || '#/library';
  const m = h.match(/^#\/read\/(.+)$/);
  if (m) {
    if (!Reader.active() || Reader.bookId() !== m[1]) { const j = App.jump; App.jump = null; Reader.open(m[1], j); }
    return;
  }
  if (Reader.active()) Reader.close();
  Sheet.close();
  const tab = h.slice(2);
  showTab(TABS.includes(tab) ? tab : 'library');
}

(async function init() {
  const step = (name, fn) => { try { return fn(); } catch (e) { console.error(name, e); showError(name + ': ' + (e && e.message || e)); } };
  loadSettings(); step('theme', () => { applyTheme(); applyLang(); });
  // navigation first, so the buttons work even if something later fails
  $('#tabbar').addEventListener('click', e => { const b = e.target.closest('button'); if (b) App.go(b.dataset.tab); });
  window.addEventListener('hashchange', () => step('route', route));
  if (typeof pdfjsLib === 'undefined') showError('PDF ইঞ্জিন (pdf.js) লোড হয়নি — APK আবার বিল্ড করুন');
  else pdfjsLib.GlobalWorkerOptions.workerSrc = 'lib/pdf.worker.min.js';
  try { await DB.open(); await Lib.load(); } catch (e) { console.error(e); showError('ডাটাবেস: ' + (e && e.message || e)); }
  step('lib', () => Lib.init()); step('reader', () => Reader.init()); step('annot', () => Annot.init()); step('notes', () => Notes.init());
  history.replaceState(null, '', '#/library');
  step('render', () => App.renderAll());
  step('route', route);
  step('auto', () => Auto.init());
})();
