const TABS = ['library', 'favs', 'notes', 'settings'];

const App = {
  jump: null,
  openBook(id, jump) { App.jump = jump || null; location.hash = '#/read/' + id; },
  go(tab) { location.replace('#/' + tab); },
  renderAll() { Lib.render(); Notes.render(); Settings.render(); }
};

function showTab(tab) {
  $$('.view').forEach(v => v.classList.toggle('on', v.id === 'v-' + tab));
  $$('#tabbar button').forEach(b => b.classList.toggle('on', b.dataset.tab === tab));
  if (tab === 'library' || tab === 'favs') Lib.render();
  if (tab === 'notes') Notes.render();
}

function route() {
  const h = location.hash || '#/library';
  const m = h.match(/^#\/read\/(.+)$/);
  if (m) {
    if (!Reader.active() || Reader.bookId() !== m[1]) { const j = App.jump; App.jump = null; Reader.open(m[1], j); }
    return;
  }
  if (Reader.active()) Reader.close();
  Sheet.close();
  const tab = h.slice(2);
  showTab(TABS.includes(tab) ? tab : 'library');
}

(async function init() {
  loadSettings(); applyTheme(); applyLang();
  pdfjsLib.GlobalWorkerOptions.workerSrc = 'lib/pdf.worker.min.js';
  await DB.open();
  await Lib.load();
  Lib.init(); Reader.init(); Annot.init(); Notes.init();
  $('#tabbar').addEventListener('click', e => { const b = e.target.closest('button'); if (b) App.go(b.dataset.tab); });
  history.replaceState(null, '', '#/library');
  window.addEventListener('hashchange', route);
  App.renderAll();
  route();
})();
