const Annot = (() => {
  let list = [], pending = null, selT = 0, hideT = 0, pen = false, drag = null, penAt = 0;
  const tb = () => $('#seltb');

  function load(bookId) { setPen(false, true); list = Data.annots.filter(a => a.bookId === bookId); renderDots(); }
  function renderDots() {
    $('#seldots').innerHTML = S.hlColors.slice(0, 3).map(c => `<i data-c="${c}" style="background:${c}"></i>`).join('');
  }

  /* ---------- drawing ---------- */
  function draw(n) {
    const el = Reader.el(n), layer = el && el.querySelector('.annot');
    if (!layer) return;
    let h = '';
    for (const a of list) {
      if (a.type === 'bm') { if (a.page === n) h += '<i class="bmk"></i>'; continue; }
      for (const p of a.parts) {
        if (p.p !== n) continue;
        p.r.forEach((r, i) => {
          const [x, y, w, hh] = r.map(v => v * 100);
          if (a.type === 'ul') h += `<i class="ul" style="left:${x}%;top:${y + hh}%;width:${w}%;border-color:${a.color}"></i>`;
          else h += `<i class="hl" style="left:${x}%;top:${y}%;width:${w}%;height:${hh}%;background:${a.color}"></i>`;
          if (a.note && i === 0) h += `<i class="nm" style="left:${x + w}%;top:${y}%"></i>`;
        });
      }
    }
    layer.innerHTML = h;
  }
  const redraw = a => (a.type === 'bm' ? [{ p: a.page }] : a.parts).forEach(p => draw(p.p));

  /* ---------- selection → rectangles ---------- */
  function mergeRects(rs) {
    rs = rs.filter(r => r.width > 1 && r.height > 1).sort((a, b) => (a.top + a.bottom) - (b.top + b.bottom));
    const lines = [];
    for (const r of rs) {
      const cy = (r.top + r.bottom) / 2, L = lines[lines.length - 1];
      if (L && Math.abs(cy - L.cy) < Math.min(L.h, r.height) * .6) {
        L.rs.push(r); L.cy = (L.cy * (L.rs.length - 1) + cy) / L.rs.length; L.h = Math.min(L.h, r.height);
      } else lines.push({ cy, h: r.height, rs: [r] });
    }
    const out = [];
    for (const L of lines) {
      const top = Math.min(...L.rs.map(r => r.top)), bottom = Math.max(...L.rs.map(r => r.bottom));
      L.rs.sort((a, b) => a.left - b.left);
      let cur = null;
      for (const r of L.rs) {
        if (cur && r.left <= cur.right + 5) cur.right = Math.max(cur.right, r.right);
        else { cur = { left: r.left, right: r.right, top, bottom }; out.push(cur); }
      }
    }
    return out.map(m => ({ left: m.left, top: m.top, width: m.right - m.left, height: m.bottom - m.top }));
  }

  function computeParts(range) {
    const pages = Reader.visiblePages(), map = new Map();
    for (const r of range.getClientRects()) {
      if (r.width < 1 || r.height < 1) continue;
      const cy = r.top + r.height / 2;
      const pg = pages.find(p => cy >= p.rect.top && cy <= p.rect.bottom);
      if (!pg || r.height > pg.rect.height * .25 || r.width > pg.rect.width * 1.02) continue;
      if (!map.has(pg.n)) map.set(pg.n, { rect: pg.rect, rs: [] });
      map.get(pg.n).rs.push(r);
    }
    const f = v => +v.toFixed(5);
    return [...map].sort((a, b) => a[0] - b[0]).map(([n, { rect, rs }]) => ({
      p: n,
      r: mergeRects(rs).map(m => [f((m.left - rect.left) / rect.width), f((m.top - rect.top) / rect.height), f(m.width / rect.width), f(m.height / rect.height)])
    })).filter(p => p.r.length);
  }

  function onSel() {
    const sel = getSelection();
    if (!sel || sel.isCollapsed || !sel.rangeCount) return hideTb();
    const range = sel.getRangeAt(0), c = range.commonAncestorContainer;
    const node = c.nodeType === 1 ? c : c.parentElement;
    if (!node || !node.closest('#pages')) return hideTb();
    const text = sel.toString().replace(/\s+/g, ' ').trim();
    if (!text) return hideTb();
    const parts = computeParts(range);
    if (!parts.length) return hideTb();
    pending = { text, parts };
    clearTimeout(hideT);
    tb().classList.add('on');
  }
  function hideTb() {
    tb().classList.remove('on');
    clearTimeout(hideT);
    hideT = setTimeout(() => { if (!tb().classList.contains('on')) pending = null; }, 700);
  }

  /* ---------- create / edit / delete ---------- */
  async function create(type, color, note = '') {
    const p = pending; if (!p) return null;
    const first = p.parts[0];
    const a = { id: uid(), bookId: Reader.bookId(), type, color, text: p.text.slice(0, 3000), note, parts: p.parts,
      page: first.p, y: first.r[0][1], created: Date.now() };
    list.push(a); Data.annots.push(a);
    await DB.put('annots', a);
    const s = getSelection(); s && s.removeAllRanges();
    pending = null; tb().classList.remove('on');
    redraw(a);
    return a;
  }

  async function copy(text) {
    try { await navigator.clipboard.writeText(text); }
    catch (e) {
      const ta = document.createElement('textarea'); ta.value = text; document.body.appendChild(ta); ta.select();
      try { document.execCommand('copy'); } catch (_) {} ta.remove();
    }
    toast(t('copied'));
  }

  async function act(k) {
    if (!pending) return;
    if (k === 'hl') await create('hl', S.hlColor);
    else if (k === 'ul') await create('ul', S.ulColor);
    else if (k === 'note') { const a = await create('hl', S.hlColor); if (a) sheet(a, true); }
    else if (k === 'copy') { await copy(pending.text); const s = getSelection(); s && s.removeAllRanges(); hideTb(); }
  }

  async function remove(a) {
    list = list.filter(x => x !== a);
    Data.annots = Data.annots.filter(x => x !== a);
    await DB.del('annots', a.id);
    redraw(a); Notes.render(); Lib.render();
    syncBm(Reader.curPos().page);
  }

  function sheet(a, focus) {
    let tmr;
    const persist = async () => { await DB.put('annots', a); redraw(a); };
    Sheet.open(`<div class="quote" id="as-q"></div>
      <div class="seg2" id="as-type"></div>
      <div class="lbl">${t('color')}</div><div class="sw" id="as-sw"></div>
      <div class="lbl">${t('note')}</div>
      <textarea class="tinput" id="as-note" rows="3" placeholder="${t('note_ph')}">${esc(a.note)}</textarea>
      <div class="btns"><button class="btn" id="as-copy"><i class="ti ti-copy"></i> ${t('copy')}</button>
      <button class="btn dng" id="as-del"><i class="ti ti-trash"></i> ${t('del')}</button></div>`, b => {
      const paint = () => {
        const ul = a.type === 'ul';
        $('#as-q', b).innerHTML = `<span class="${ul ? 'ult' : 'hlt'}" style="${ul ? 'border-color:' + a.color : 'background:' + a.color}">${esc(a.text)}</span>`;
        $('#as-type', b).innerHTML = `<button data-ty="hl" class="${ul ? '' : 'on'}">${t('hl')}</button><button data-ty="ul" class="${ul ? 'on' : ''}">${t('ul')}</button>`;
        const pal = ul ? S.ulColors : S.hlColors;
        $('#as-sw', b).innerHTML = swatchesHTML(pal.includes(a.color) ? pal : [a.color, ...pal], a.color, false);
      };
      paint();
      $('#as-type', b).onclick = e => {
        const k = e.target.closest('[data-ty]'); if (!k) return;
        a.type = k.dataset.ty; a.color = a.type === 'ul' ? S.ulColor : S.hlColor; paint(); persist();
      };
      $('#as-sw', b).onclick = e => { const d = e.target.closest('[data-c]'); if (d) { a.color = d.dataset.c; paint(); persist(); } };
      const nt = $('#as-note', b);
      nt.oninput = () => { a.note = nt.value; clearTimeout(tmr); tmr = setTimeout(persist, 400); };
      $('#as-copy', b).onclick = () => copy(a.text);
      $('#as-del', b).onclick = async () => { Sheet.close(); if (await ask(t('del_note_q'), '', t('del'))) remove(a); };
      if (focus) setTimeout(() => nt.focus(), 260);
    });
    Sheet.onClose = () => { clearTimeout(tmr); persist(); Notes.render(); };
  }

  function tap(n, e, el) {
    const r = el.getBoundingClientRect();
    const x = (e.clientX - r.left) / r.width, y = (e.clientY - r.top) / r.height;
    const hit = [...list].reverse().find(a => a.type !== 'bm' && a.parts.some(p => p.p === n &&
      p.r.some(q => x >= q[0] - .004 && x <= q[0] + q[2] + .004 && y >= q[1] - .008 && y <= q[1] + q[3] * 1.4 + .004)));
    if (hit) { sheet(hit); return true; }
    return false;
  }

  /* ---------- bookmarks ---------- */
  function toggleBm(pos) {
    const ex = list.find(a => a.type === 'bm' && a.page === pos.page);
    if (ex) { remove(ex); toast(t('bm_rm')); return; }
    const a = { id: uid(), bookId: Reader.bookId(), type: 'bm', color: '#E24B4A', text: '', note: '', parts: [], page: pos.page, y: 0, created: Date.now() };
    list.push(a); Data.annots.push(a); DB.put('annots', a);
    draw(pos.page); syncBm(pos.page); toast(t('bm_add'));
  }
  function syncBm(page) {
    $('#r-bm').style.color = list.some(a => a.type === 'bm' && a.page === page) ? 'var(--danger)' : '';
  }

  function listSheet() {
    const items = [...list].sort((a, b) => a.page - b.page || a.y - b.y);
    const ic = a => a.type === 'bm' ? 'bookmark' : a.type === 'ul' ? 'underline' : 'highlight';
    Sheet.open(`<h3 class="sh-t">${t('book_notes')}</h3><div style="height:8px"></div>` + (items.length ? items.map(a =>
      `<button class="opt" data-id="${a.id}" style="align-items:flex-start"><i class="ti ti-${ic(a)}" style="color:${a.color}"></i>
       <span style="flex:1"><span style="font-size:13px;line-height:1.6;display:block">${esc(a.type === 'bm' ? t('bm') : a.text.slice(0, 140))}</span>
       <small style="color:var(--text2)">${t('page')} ${num(a.page)}</small></span></button>`).join('') : `<p class="sh-d">${t('empty_nd')}</p>`), b => {
      b.onclick = e => {
        const o = e.target.closest('.opt'); if (!o) return;
        const a = list.find(x => x.id === o.dataset.id); Sheet.close();
        a && Reader.goTo(a.page, Math.max(0, a.y - .02));
      };
    });
  }

  /* ---------- highlight mode: drag sideways over text (or over a scanned page) ---------- */
  function setPen(on, quiet) {
    pen = on; drag = null;
    const h = $('#pages'), b = $('#r-pen'), bx = $('#penbox');
    h && h.classList.toggle('pen', on); b && b.classList.toggle('on', on); bx && (bx.style.display = 'none');
    if (!on) { const s = getSelection(); s && s.removeAllRanges(); hideTb(); }
    if (!quiet) toast(t(on ? 'pen_on' : 'pen_off'));
  }
  function caretAt(x, y) {
    for (const [dx, dy] of [[0, 0], [0, -5], [0, 5], [0, -10], [0, 10], [0, -16], [0, 16], [10, 0], [-10, 0]]) {
      let r = null;
      try {
        if (document.caretRangeFromPoint) r = document.caretRangeFromPoint(x + dx, y + dy);
        else if (document.caretPositionFromPoint) {
          const p = document.caretPositionFromPoint(x + dx, y + dy);
          if (p) { r = document.createRange(); r.setStart(p.offsetNode, p.offset); }
        }
      } catch (e) {}
      const n = r && r.startContainer;
      if (n && n.nodeType === 3 && n.parentElement && n.parentElement.closest('.textLayer')) return { node: n, off: r.startOffset };
    }
    return null;
  }
  function boxOf(d) {
    const x1 = Math.min(d.x0, d.x), x2 = Math.max(d.x0, d.x);
    let y1 = Math.min(d.y0, d.y), y2 = Math.max(d.y0, d.y);
    if (y2 - y1 < 14) { y1 = d.y0 - 9; y2 = d.y0 + 9; }
    return { x1, x2, y1, y2 };
  }
  function showBox(d) {
    const b = boxOf(d), el = $('#penbox');
    el.style.cssText = `display:block;left:${b.x1}px;top:${b.y1}px;width:${b.x2 - b.x1}px;height:${b.y2 - b.y1}px`;
  }
  function freehand(d) {
    const b = boxOf(d);
    const pg = Reader.visiblePages().find(p => d.y0 >= p.rect.top && d.y0 <= p.rect.bottom && d.x0 >= p.rect.left && d.x0 <= p.rect.right);
    if (!pg) return;
    const R = pg.rect, x1 = Math.max(b.x1, R.left), x2 = Math.min(b.x2, R.right), y1 = Math.max(b.y1, R.top), y2 = Math.min(b.y2, R.bottom);
    if (x2 - x1 < 6 || y2 - y1 < 4) return;
    const f = v => +v.toFixed(5);
    pending = { text: `${t('area')} · ${t('page')} ${pg.n}`, parts: [{ p: pg.n, r: [[f((x1 - R.left) / R.width), f((y1 - R.top) / R.height), f((x2 - x1) / R.width), f((y2 - y1) / R.height)]] }] };
    clearTimeout(hideT); tb().classList.add('on');
  }
  function initPen() {
    const h = $('#pages');
    $('#r-pen').onclick = () => setPen(!pen);
    h.addEventListener('pointerdown', e => {
      if (!pen) return;
      if (drag) { drag.cancel = true; return; }          // a second finger = pinch, not drawing
      const s = getSelection(); if (s && !s.isCollapsed) s.removeAllRanges();
      drag = { id: e.pointerId, x0: e.clientX, y0: e.clientY, x: e.clientX, y: e.clientY, start: caretAt(e.clientX, e.clientY), moved: false };
    });
    h.addEventListener('pointermove', e => {
      if (!drag || e.pointerId !== drag.id || drag.cancel) return;
      drag.x = e.clientX; drag.y = e.clientY;
      if (!drag.moved && Math.hypot(drag.x - drag.x0, drag.y - drag.y0) < 8) return;
      drag.moved = true;
      if (drag.start) {
        const end = caretAt(drag.x, drag.y);
        if (end) { try { getSelection().setBaseAndExtent(drag.start.node, drag.start.off, end.node, end.off); } catch (_) {} }
      } else showBox(drag);
    });
    h.addEventListener('pointerup', e => {
      if (!drag || e.pointerId !== drag.id) return;
      const d = drag; drag = null; $('#penbox').style.display = 'none';
      if (!d.moved || d.cancel) return;
      penAt = Date.now();
      if (d.start) { clearTimeout(selT); selT = setTimeout(onSel, 30); } else freehand(d);
    });
    h.addEventListener('pointercancel', () => { drag = null; $('#penbox').style.display = 'none'; });
  }

  function init() {
    initPen();
    document.addEventListener('selectionchange', () => {
      if (!Reader.active()) return;
      clearTimeout(selT); selT = setTimeout(onSel, 200);
    });
    const bar = tb();
    bar.addEventListener('pointerdown', e => e.preventDefault());
    bar.addEventListener('click', async e => {
      const d = e.target.closest('#seldots i');
      if (d) { await create('hl', d.dataset.c); return; }
      const b = e.target.closest('button'); if (b) act(b.dataset.a);
    });
  }

  return { init, load, draw, tap, penRecent: () => Date.now() - penAt < 450, setPen, toggleBm, syncBm, listSheet, hideTb, renderDots };
})();
