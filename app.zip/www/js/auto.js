/* Auto-import: finds PDFs anywhere on the phone (needs "all files access") and adds them to the library automatically */
const Auto = (() => {
  const BF = (window.Capacitor && Capacitor.isNativePlatform && Capacitor.isNativePlatform()) ? Capacitor.registerPlugin('BoighorFiles') : null;
  const SEEN = 'boighor.seen', ASKED = 'boighor.asked';
  const key = f => f.path + '|' + f.size + '|' + f.mtime;
  const getSeen = () => { try { return new Set(JSON.parse(localStorage.getItem(SEEN) || '[]')); } catch (e) { return new Set(); } };
  const putSeen = s => { try { localStorage.setItem(SEEN, JSON.stringify([...s])); } catch (e) {} };
  let busy = false, waiting = false;

  const available = () => !!BF;
  const granted = async () => { try { return !!(await BF.status()).granted; } catch (e) { return false; } };
  const list = async () => { try { return (await BF.listPdfs()).files || []; } catch (e) { return []; } };

  function permSheet() {
    return new Promise(res => {
      let go = false;
      Sheet.open(`<h3 class="sh-t">${t('perm_t')}</h3><p class="sh-d">${t('perm_d')}</p>
        <div class="btns"><button class="btn" id="p-no">${t('later')}</button><button class="btn pri" id="p-go">${t('perm_go')}</button></div>`, b => {
        $('#p-no', b).onclick = () => Sheet.close();
        $('#p-go', b).onclick = () => { go = true; Sheet.close(); };
      });
      Sheet.onClose = () => res(go);
    });
  }

  const pause = ms => new Promise(r => setTimeout(r, ms));
  const BATCH = 12;   // books per round, so the app stays responsive

  /* Adds PDFs from the phone that are not in the library yet, a few at a time in the background. */
  async function scan(manual) {
    if (!BF || busy || !S.auto) return 0;
    busy = true; let added = 0, more = false;
    try {
      if (!(await granted())) return 0;
      const seen = getSeen(), now = Date.now();
      const fresh = (await list()).filter(f => !seen.has(key(f)) && now - f.mtime > 4000).sort((a, b) => b.mtime - a.mtime);
      if (manual && fresh.length) toast(`${num(fresh.length)}${t('auto_checking')}`);
      more = fresh.length > BATCH;
      for (const f of fresh.slice(0, BATCH)) {
        if (document.hidden) { more = true; break; }
        try {
          const res = await fetch(location.origin + '/_capacitor_file_' + encodeURI(f.path));
          if (!res.ok) throw new Error('HTTP ' + res.status);
          const file = new File([await res.blob()], f.name, { type: 'application/pdf' });
          added += await Lib.addFiles([file], true);
        } catch (e) { console.warn('auto', f.path, e); }
        seen.add(key(f)); putSeen(seen);
        await pause(60);   // let taps and scrolling through
      }
      if (added) { Lib.render(); toast(`${num(added)}${t('auto_found')}`); }
    } catch (e) { console.warn('auto scan', e); }
    finally { busy = false; }
    if (more) setTimeout(() => scan(), 3000);
    return added;
  }

  async function afterGranted() {
    S.auto = true; saveSettings();
    Settings.render(); Lib.render();
    scan(true);
  }

  async function enable() {
    if (!BF) return;
    if (await granted()) return afterGranted();
    if (!(await permSheet())) { S.auto = false; saveSettings(); Settings.render(); Lib.render(); return; }
    waiting = true;
    try { await BF.requestAccess(); } catch (e) { waiting = false; }
  }
  async function requestAccess() {
    if (!BF) return;
    S.auto = true; saveSettings();
    waiting = true;
    try { await BF.requestAccess(); } catch (e) { waiting = false; showError('অনুমতির পেজ খোলা যায়নি: ' + (e && e.message || e)); }
  }
  function disable() { S.auto = false; saveSettings(); Settings.render(); Lib.render(); }

  function init() {
    if (!BF) return;
    document.addEventListener('visibilitychange', async () => {
      if (document.hidden) return;
      if (waiting && await granted()) { waiting = false; afterGranted(); }
      else if (S.auto) scan();
    });
    // keep the library up to date while the app is open (e.g. after a download finishes)
    setInterval(() => { if (!document.hidden && S.auto && !Sheet.isOpen && !Reader.active()) scan(); }, 30000);

    let asked = false;
    try { asked = !!localStorage.getItem(ASKED); } catch (e) {}
    if (!asked) {
      // first launch: turn auto-import on by default and ask for file access once
      try { localStorage.setItem(ASKED, '1'); } catch (e) {}
      setTimeout(() => enable().catch(() => {}), 600);
    } else if (S.auto) scan();
  }
  return { init, available, enable, disable, scan, granted, requestAccess };
})();
