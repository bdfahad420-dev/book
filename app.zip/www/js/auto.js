/* Auto-import: finds new PDFs in Download/Documents (needs "all files access") and adds them to the library */
const Auto = (() => {
  const BF = (window.Capacitor && Capacitor.isNativePlatform && Capacitor.isNativePlatform()) ? Capacitor.registerPlugin('BoighorFiles') : null;
  const SEEN = 'boighor.seen', BASE = 'boighor.base';
  const key = f => f.path + '|' + f.size + '|' + f.mtime;
  const getSeen = () => { try { return new Set(JSON.parse(localStorage.getItem(SEEN) || '[]')); } catch (e) { return new Set(); } };
  const putSeen = s => { try { localStorage.setItem(SEEN, JSON.stringify([...s])); } catch (e) {} };
  let busy = false, waiting = false;

  const available = () => !!BF;
  const granted = async () => { try { return !!(await BF.status()).granted; } catch (e) { return false; } };
  const list = async () => { try { return (await BF.listPdfs()).files || []; } catch (e) { return []; } };

  function permSheet() {
    return new Promise(res => {
      let go = false;
      Sheet.open(`<h3 class="sh-t">${t('perm_t')}</h3><p class="sh-d">${t('perm_d')}</p>
        <div class="btns"><button class="btn" id="p-no">${t('cancel')}</button><button class="btn pri" id="p-go">${t('perm_go')}</button></div>`, b => {
        $('#p-no', b).onclick = () => Sheet.close();
        $('#p-go', b).onclick = () => { go = true; Sheet.close(); };
      });
      Sheet.onClose = () => res(go);
    });
  }
  function baseSheet() {
    return new Promise(res => {
      let all = false;
      Sheet.open(`<h3 class="sh-t">${t('base_t')}</h3><p class="sh-d">${t('base_d')}</p>
        <div class="btns"><button class="btn" id="b-new">${t('base_new')}</button><button class="btn pri" id="b-all">${t('base_all')}</button></div>`, b => {
        $('#b-new', b).onclick = () => Sheet.close();
        $('#b-all', b).onclick = () => { all = true; Sheet.close(); };
      });
      Sheet.onClose = () => res(all);
    });
  }

  async function scan() {
    if (!BF || busy || !S.auto) return 0;
    busy = true; let added = 0;
    try {
      if (!(await granted())) return 0;
      const seen = getSeen(), now = Date.now();
      const fresh = (await list()).filter(f => !seen.has(key(f)) && now - f.mtime > 4000).sort((a, b) => a.mtime - b.mtime);
      for (const f of fresh) {
        try {
          const res = await fetch(location.origin + '/_capacitor_file_' + encodeURI(f.path));
          const file = new File([await res.blob()], f.name, { type: 'application/pdf' });
          added += await Lib.addFiles([file], true);
        } catch (e) { console.warn('auto', e); }
        seen.add(key(f)); putSeen(seen);
      }
      if (added) toast(`${num(added)}${t('auto_found')}`);
    } finally { busy = false; }
    return added;
  }

  async function afterGranted() {
    if (!localStorage.getItem(BASE)) {
      const all = await baseSheet();
      if (!all) { const seen = getSeen(); (await list()).forEach(f => seen.add(key(f))); putSeen(seen); }
      try { localStorage.setItem(BASE, '1'); } catch (e) {}
    }
    S.auto = true; saveSettings();
    Settings.render(); Lib.render();
    scan();
  }

  async function enable() {
    if (!BF) return;
    if (await granted()) return afterGranted();
    if (!(await permSheet())) return;
    waiting = true;
    try { await BF.requestAccess(); } catch (e) { waiting = false; }
  }
  function disable() { S.auto = false; saveSettings(); Settings.render(); Lib.render(); }

  function init() {
    if (!BF) return;
    document.addEventListener('visibilitychange', async () => {
      if (document.hidden) return;
      if (waiting && await granted()) { waiting = false; afterGranted(); }
      else if (S.auto) scan();
    });
    if (S.auto) scan();
  }
  return { init, available, enable, disable, scan, granted };
})();
