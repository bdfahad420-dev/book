const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);

const DEF_HL = ['#FAC775', '#97C459', '#ED93B1', '#85B7EB'];
const DEF_UL = ['#E24B4A', '#378ADD', '#1D9E75', '#7F77DD'];
const S = {
  lang: 'bn', theme: 'light', view: 'grid', filter: 'all', sort: 'recent', q: '',
  hlColors: DEF_HL.slice(), ulColors: DEF_UL.slice(), hlColor: DEF_HL[0], ulColor: DEF_UL[1], auto: false
};
const Data = { books: [], annots: [] };

function loadSettings() {
  try { Object.assign(S, JSON.parse(localStorage.getItem('boighor.s') || '{}')); } catch (e) {}
}
function saveSettings() {
  try {
    const { lang, theme, view, sort, hlColors, ulColors, hlColor, ulColor, auto } = S;
    localStorage.setItem('boighor.s', JSON.stringify({ lang, theme, view, sort, hlColors, ulColors, hlColor, ulColor, auto }));
  } catch (e) {}
}

const BN = '০১২৩৪৫৬৭৮৯';
const num = n => S.lang === 'bn' ? String(n).replace(/\d/g, d => BN[d]) : String(n);
const t = k => (I18N[S.lang] && I18N[S.lang][k]) || k;

function applyTheme() {
  document.documentElement.dataset.theme = S.theme;
  const m = document.querySelector('meta[name=theme-color]');
  if (m) m.content = { light: '#F6F5F1', dark: '#141413', sepia: '#F4ECD8' }[S.theme];
}
function applyLang() {
  document.documentElement.lang = S.lang;
  $$('[data-i]').forEach(e => e.textContent = t(e.dataset.i));
  $$('[data-ph]').forEach(e => e.placeholder = t(e.dataset.ph));
}

let toastT;
function toast(msg) {
  const el = $('#toast');
  el.textContent = msg; el.classList.add('on');
  clearTimeout(toastT); toastT = setTimeout(() => el.classList.remove('on'), 2200);
}

const Sheet = {
  onClose: null,
  open(html, mount) {
    $('#sbody').innerHTML = html;
    $('#sbg').classList.add('on');
    $('#sheet').scrollTop = 0;
    mount && mount($('#sbody'));
  },
  close() {
    if (!$('#sbg').classList.contains('on')) return;
    $('#sbg').classList.remove('on');
    const f = Sheet.onClose; Sheet.onClose = null;
    f && f();
  },
  get isOpen() { return $('#sbg').classList.contains('on'); }
};
$('#sbg').addEventListener('click', e => { if (e.target.id === 'sbg') Sheet.close(); });

function ask(title, msg, okLabel, danger = true) {
  return new Promise(res => {
    let result = false;
    Sheet.open(`<h3 class="sh-t">${esc(title)}</h3><p class="sh-d">${esc(msg || '')}</p>
      <div class="btns"><button class="btn" id="a-no">${t('cancel')}</button>
      <button class="btn ${danger ? 'dng' : 'pri'}" id="a-yes">${esc(okLabel || t('ok'))}</button></div>`, b => {
      $('#a-no', b).onclick = () => Sheet.close();
      $('#a-yes', b).onclick = () => { result = true; Sheet.close(); };
    });
    Sheet.onClose = () => res(result);
  });
}

function askText(title, value) {
  return new Promise(res => {
    let result = null;
    Sheet.open(`<h3 class="sh-t">${esc(title)}</h3>
      <input class="tinput" id="a-in" value="${esc(value || '')}" style="margin-top:10px">
      <div class="btns"><button class="btn" id="a-no">${t('cancel')}</button>
      <button class="btn pri" id="a-yes">${t('save')}</button></div>`, b => {
      const inp = $('#a-in', b);
      $('#a-no', b).onclick = () => Sheet.close();
      $('#a-yes', b).onclick = () => { result = inp.value.trim(); Sheet.close(); };
      setTimeout(() => { inp.focus(); inp.select(); }, 120);
    });
    Sheet.onClose = () => res(result);
  });
}

/* Color picker sheet: presets + native color input */
const PRESETS = ['#FAC775', '#F5C4B3', '#F4C0D1', '#CECBF6', '#B5D4F4', '#9FE1CB', '#C0DD97', '#EF9F27', '#E24B4A', '#D4537E', '#7F77DD', '#378ADD', '#1D9E75', '#639922', '#BA7517', '#444441'];
function pickColor() {
  return new Promise(res => {
    let result = null;
    Sheet.open(`<h3 class="sh-t">${t('add_color')}</h3>
      <div class="sw" style="margin:14px 0">${PRESETS.map(c => `<button class="dot" data-c="${c}" style="background:${c}"></button>`).join('')}</div>
      <div class="lbl">${t('custom')}</div>
      <input type="color" id="a-col" value="#FAC775" style="width:100%;height:46px;border:0;background:none;padding:0">`, b => {
      $$('.dot', b).forEach(d => d.onclick = () => { result = d.dataset.c; Sheet.close(); });
      $('#a-col', b).onchange = e => { result = e.target.value; Sheet.close(); };
    });
    Sheet.onClose = () => res(result);
  });
}

const optHTML = (icon, label, id, cls = '') => `<button class="opt ${cls}" data-id="${id}"><i class="ti ti-${icon}"></i>${esc(label)}</button>`;

/* Swatches row with tap to choose, long-press to remove */
function swatchesHTML(colors, cur, add = true) {
  return colors.map(c => `<button class="dot ${c === cur ? 'on' : ''}" data-c="${c}" style="background:${c}"></button>`).join('') +
    (add ? `<button class="dot add" data-add="1"><i class="ti ti-plus"></i></button>` : '');
}
