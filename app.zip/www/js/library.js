const PDF_OPTS = { cMapUrl: 'lib/cmaps/', cMapPacked: true, standardFontDataUrl: 'lib/standard_fonts/' };

const Lib = (() => {
  const PAL = [['#E1F5EE', '#085041'], ['#EEEDFE', '#3C3489'], ['#FAECE7', '#712B13'], ['#FBEAF0', '#72243E'], ['#E6F1FB', '#0C447C'], ['#FAEEDA', '#633806']];
  const hash = s => [...s].reduce((a, c) => (a * 31 + c.charCodeAt(0)) >>> 0, 7);
  const pct = b => Math.round((b.progress || 0) * 100);
  const isDone = b => (b.progress || 0) >= .97;
  const isReading = b => (b.progress || 0) > 0 && !isDone(b);
  const pathHidden = p => !!p && (S.hiddenFolders || []).some(d => p.startsWith(d + '/'));
  const isHidden = b => !!(b.hidden || pathHidden(b.src));
  const visible = () => Data.books.filter(b => !isHidden(b));
  const hlCount = id => Data.annots.filter(a => a.bookId === id && a.type !== 'bm').length;

  const coverInner = b => {
    if (b.cover) return `<img src="${b.cover}" alt="">`;
    const p = PAL[hash(b.id) % PAL.length];
    return `<div class="fb" style="background:${p[0]};color:${p[1]}">${esc(b.title)}</div>`;
  };
  const heart = b => `<button class="heart ${b.fav ? 'f' : ''}" data-act="fav" aria-label="favorite"><i class="ti ti-heart"></i></button>`;
  const more = () => `<button class="more" data-act="more" aria-label="more"><i class="ti ti-dots-vertical"></i></button>`;
  const emptyHTML = (icon, tk, dk) => `<div class="empty"><i class="ti ti-${icon}"></i><h3>${t(tk)}</h3>${dk ? `<p>${t(dk)}</p>` : ''}</div>`;

  function cardHTML(b) {
    const st = b.progress > 0 ? `${num(pct(b))}%` : t('not_started');
    return `<div class="card" data-id="${b.id}">
      <div class="cover">${coverInner(b)}${heart(b)}<div class="bar"><i style="width:${pct(b)}%"></i></div></div>
      <div class="cmeta"><div class="grow"><div class="ct">${esc(b.title)}</div><div class="cs">${esc(b.author ? b.author + ' · ' : '')}${st}</div></div>${more()}</div></div>`;
  }
  function rowHTML(b, extra) {
    const st = extra || (b.progress > 0 ? `${t('page')} ${num(b.lastPage)}/${num(b.pages)}` : t('not_started'));
    return `<div class="row" data-id="${b.id}">
      <div class="th">${coverInner(b)}</div>
      <div class="rb"><div class="rt">${esc(b.title)}</div><div class="rs">${esc(b.author ? b.author + ' · ' : '')}${st}</div>
      <div class="rp"><div class="bar"><i style="width:${pct(b)}%"></i></div><span>${num(pct(b))}%</span></div></div>
      ${heart(b)}${more()}</div>`;
  }

  function filtered() {
    let l = visible();
    const q = S.q.trim().toLowerCase();
    if (q) l = l.filter(b => (b.title + ' ' + (b.author || '')).toLowerCase().includes(q));
    if (S.filter === 'reading') l = l.filter(isReading);
    else if (S.filter === 'fav') l = l.filter(b => b.fav);
    else if (S.filter === 'done') l = l.filter(isDone);
    const s = S.sort;
    l.sort((a, b) => s === 'name' ? a.title.localeCompare(b.title, 'bn') : s === 'prog' ? (b.progress || 0) - (a.progress || 0) :
      s === 'added' ? b.addedAt - a.addedAt : (b.lastOpened || 0) - (a.lastOpened || 0));
    return l;
  }

  function render() {
    const h = new Date().getHours();
    $('#hello').textContent = t(h < 5 ? 'hi_l' : h < 12 ? 'hi_m' : h < 16 ? 'hi_n' : h < 19 ? 'hi_a' : h < 22 ? 'hi_e' : 'hi_l');

    const rb = visible().filter(isReading).sort((a, b) => (b.lastOpened || 0) - (a.lastOpened || 0))[0];
    $('#resume').innerHTML = (!rb || S.q) ? '' : `<div class="resume" data-id="${rb.id}">
      <div class="rc">${coverInner(rb)}</div>
      <div class="grow"><small>${t('cont')}</small><b>${esc(rb.title)}</b><small>${t('page')} ${num(rb.lastPage)} · ${num(pct(rb))}%</small>
      <div class="bar"><i style="width:${pct(rb)}%"></i></div></div><span class="go"><i class="ti ti-player-play"></i></span></div>`;

    $('#chips').innerHTML = [['all', 'all'], ['reading', 'reading'], ['fav', 'favs'], ['done', 'done']]
      .map(([k, l]) => `<button class="chip ${S.filter === k ? 'on' : ''}" data-f="${k}">${t(l)}</button>`).join('');
    $$('#vt button').forEach(b => b.classList.toggle('on', b.dataset.v === S.view));

    const box = $('#books'), l = filtered();
    if (!visible().length) {
      box.innerHTML = emptyHTML('books', 'empty_t', 'empty_d') +
        (Auto.available() && !S.auto ? `<div style="text-align:center"><button class="btn pri" id="e-auto" style="flex:none;padding:0 22px">${t('auto_enable')}</button></div>` : '');
      const eb = $('#e-auto'); if (eb) eb.onclick = () => Auto.enable();
    }
    else if (!l.length) box.innerHTML = emptyHTML('search', 'empty_s');
    else box.innerHTML = S.view === 'grid' ? `<div class="grid">${l.map(cardHTML).join('')}</div>` : `<div class="rows">${l.map(b => rowHTML(b)).join('')}</div>`;

    const fv = visible().filter(b => b.fav).sort((a, b) => (b.lastOpened || 0) - (a.lastOpened || 0));
    $('#fav-cnt').textContent = fv.length ? num(fv.length) + t('n_books') : '';
    $('#fav-list').innerHTML = fv.length ? `<div class="rows">${fv.map(b => rowHTML(b, `${num(hlCount(b.id))} ${t('hl')}`)).join('')}</div>` : emptyHTML('heart', 'empty_f', 'empty_fd');
  }

  async function toggleFav(id) {
    const b = Data.books.find(x => x.id === id); if (!b) return;
    b.fav = !b.fav; await DB.put('books', b); render();
  }

  function menu(id) {
    const b = Data.books.find(x => x.id === id); if (!b) return;
    Sheet.open(`<h3 class="sh-t">${esc(b.title)}</h3><div style="height:8px"></div>
      ${optHTML('heart', b.fav ? t('fav_rm') : t('fav_add'), 'fav')}
      ${optHTML('pencil', t('rename'), 'ren')}
      ${optHTML('eye-off', t('hide'), 'hide')}
      ${b.src ? optHTML('folder-off', t('hide_folder') + ' · ' + Hide.folderName(Hide.dirOf(b.src)), 'hidef') : ''}
      ${optHTML(isDone(b) ? 'refresh' : 'circle-check', isDone(b) ? t('mark_undone') : t('mark_done'), 'done')}
      ${optHTML('trash', t('del'), 'del', 'danger')}`, body => {
      body.onclick = async e => {
        const o = e.target.closest('.opt'); if (!o) return;
        Sheet.close();
        if (o.dataset.id === 'fav') toggleFav(id);
        else if (o.dataset.id === 'hide') { b.hidden = true; await DB.put('books', b); render(); Notes.render(); toast(t('hid')); }
        else if (o.dataset.id === 'hidef') { Hide.hideFolder(Hide.dirOf(b.src)); toast(t('hid_f')); }
        else if (o.dataset.id === 'ren') {
          const n = await askText(t('book_name'), b.title);
          if (n) { b.title = n; await DB.put('books', b); render(); }
        } else if (o.dataset.id === 'done') {
          if (isDone(b)) { b.progress = 0; b.lastPage = 1; b.lastOffset = 0; } else b.progress = 1;
          await DB.put('books', b); render();
        } else if (o.dataset.id === 'del') {
          if (await ask(t('del_book_q'), t('del_book_d'), t('del'))) await remove(id);
        }
      };
    });
  }

  async function remove(id) {
    const ids = Data.annots.filter(a => a.bookId === id).map(a => a.id);
    await DB.del('files', id); await DB.del('books', id); await DB.delMany('annots', ids);
    Data.books = Data.books.filter(b => b.id !== id);
    Data.annots = Data.annots.filter(a => a.bookId !== id);
    render(); Notes.render();
  }

  function sortSheet() {
    const items = [['recent', 's_recent', 'clock'], ['name', 's_name', 'sort-ascending-letters'], ['prog', 's_prog', 'progress'], ['added', 's_added', 'calendar-plus']];
    Sheet.open(`<h3 class="sh-t">${t('sort')}</h3><div style="height:8px"></div>` +
      items.map(([k, l, ic]) => `<button class="opt" data-id="${k}"><i class="ti ti-${ic}"></i>${t(l)}${S.sort === k ? '<i class="ti ti-check"></i>' : ''}</button>`).join(''), body => {
      body.onclick = e => {
        const o = e.target.closest('.opt'); if (!o) return;
        S.sort = o.dataset.id; saveSettings(); Sheet.close(); render();
      };
    });
  }

  async function makeCover(pdf) {
    try {
      const page = await pdf.getPage(1);
      const v0 = page.getViewport({ scale: 1 });
      const vp = page.getViewport({ scale: 280 / v0.width });
      const cv = document.createElement('canvas');
      cv.width = Math.floor(vp.width); cv.height = Math.floor(vp.height);
      await page.render({ canvasContext: cv.getContext('2d'), viewport: vp }).promise;
      return cv.toDataURL('image/jpeg', .72);
    } catch (e) { return ''; }
  }

  async function addFiles(files, quiet) {
    let n = 0;
    for (const f of files) {
      const ex = Data.books.find(b => b.name === f.name && b.size === f.size);
      if (ex) { if (f.src && !ex.src) { ex.src = f.src; DB.put('books', ex); } if (!quiet) toast(t('dup')); continue; }
      if (!quiet) toast(t('adding'));
      try {
        const buf = new Uint8Array(await f.arrayBuffer());
        const pdf = await pdfjsLib.getDocument({ data: buf, ...PDF_OPTS }).promise;
        const meta = await pdf.getMetadata().catch(() => null);
        const book = {
          id: uid(), name: f.name, size: f.size, src: f.src || '', hidden: false, title: f.name.replace(/\.pdf$/i, ''),
          author: (meta && meta.info && meta.info.Author || '').trim(), pages: pdf.numPages,
          cover: await makeCover(pdf), addedAt: Date.now(), lastOpened: 0,
          lastPage: 1, lastOffset: 0, progress: 0, fav: false, zoom: 1
        };
        pdf.destroy();
        await DB.put('files', { id: book.id, blob: f });
        await DB.put('books', book);
        Data.books.push(book); n++; if (!quiet) render();
      } catch (e) { console.error(e); if (!quiet) toast(t('bad_pdf')); }
    }
    if (n && !quiet) toast(t('added'));
    return n;
  }

  function init() {
    const click = (el, fn) => el.addEventListener('click', fn);
    const bind = el => click(el, e => {
      const c = e.target.closest('[data-id]'); if (!c) return;
      const act = e.target.closest('[data-act]');
      if (act) { e.stopPropagation(); act.dataset.act === 'fav' ? toggleFav(c.dataset.id) : menu(c.dataset.id); return; }
      App.openBook(c.dataset.id);
    });
    ['#books', '#fav-list', '#resume'].forEach(s => bind($(s)));
    click($('#chips'), e => { const c = e.target.closest('[data-f]'); if (c) { S.filter = c.dataset.f; render(); } });
    click($('#vt'), e => { const c = e.target.closest('[data-v]'); if (c) { S.view = c.dataset.v; saveSettings(); render(); } });
    click($('#btn-sort'), sortSheet);
    click($('#fab'), () => $('#file-input').click());
    click($('#btn-search'), () => {
      const bar = $('#searchbar'); bar.classList.toggle('on');
      if (bar.classList.contains('on')) $('#q').focus(); else { S.q = ''; $('#q').value = ''; render(); }
    });
    $('#q').addEventListener('input', e => { S.q = e.target.value; render(); });
    $('#file-input').addEventListener('change', e => { const fl = [...e.target.files]; e.target.value = ''; addFiles(fl); });
  }

  async function load() {
    Data.books = await DB.all('books');
    Data.annots = await DB.all('annots');
  }
  return { init, load, render, hlCount, addFiles, isHidden, pathHidden, visible };
})();
