const Reader = (() => {
  let pdf = null, book = null, sizes = [], els = [], scales = [], zoom = 1;
  let io = null, ready = false, raf = 0, saveT = 0, active = false, dragging = false, actT = 0;
  const rendered = new Map();
  const TOP = 56; // height of the top bar: the reading position is measured just below it
  const host = () => $('#pages');

  async function open(id, jump) {
    const b = Data.books.find(x => x.id === id);
    if (!b) { App.go('library'); return; }
    book = b; active = true; ready = false;
    zoom = b.zoom || 1;
    $('#v-reader').classList.add('on');
    $('#v-reader').classList.remove('hide-ui');
    $('#r-load').classList.add('on');
    $('#r-title').textContent = b.title;
    $('#pin').innerHTML = '';
    syncIcons();
    try {
      const rec = await DB.get('files', id);
      const buf = new Uint8Array(await rec.blob.arrayBuffer());
      pdf = await pdfjsLib.getDocument({ data: buf, ...PDF_OPTS }).promise;
    } catch (e) {
      console.error(e); toast(t('bad_pdf')); history.back(); return;
    }
    await measure();
    layout();
    Annot.load(id);
    const n = sizes.length;
    const p = jump || { page: b.lastPage || 1, off: b.lastOffset || 0 };
    goTo(Math.min(Math.max(1, p.page), n), p.off || 0);
    ready = true;
    updateUI(curPos());
    $('#r-load').classList.remove('on');
    b.lastOpened = Date.now();
    DB.put('books', b);
  }

  async function measure() {
    const n = pdf.numPages;
    const first = await pdf.getPage(1);
    const v = first.getViewport({ scale: 1 });
    sizes = Array.from({ length: n }, () => ({ w: v.width, h: v.height }));
    const lim = Math.min(n, 600);
    for (let s = 0; s < lim; s += 25) {
      await Promise.all(Array.from({ length: Math.min(25, lim - s) }, async (_, k) => {
        const pg = await pdf.getPage(s + k + 1);
        const vp = pg.getViewport({ scale: 1 });
        sizes[s + k] = { w: vp.width, h: vp.height };
      }));
    }
  }

  function layout() {
    const pin = $('#pin');
    pin.innerHTML = '';
    rendered.clear();
    const avail = host().clientWidth - 12;
    scales = sizes.map(s => avail / s.w * zoom);
    els = sizes.map((s, i) => {
      const d = document.createElement('div');
      d.className = 'page'; d.dataset.n = i + 1;
      d.style.width = s.w * scales[i] + 'px'; d.style.height = s.h * scales[i] + 'px';
      pin.appendChild(d); return d;
    });
    if (io) io.disconnect();
    io = new IntersectionObserver(es => es.forEach(en => {
      const n = +en.target.dataset.n;
      en.isIntersecting ? render(n) : unrender(n);
    }), { root: host(), rootMargin: '120% 0px' });
    els.forEach(e => io.observe(e));
  }

  async function render(n) {
    if (rendered.has(n) || !pdf) return;
    const tok = {}; rendered.set(n, tok);
    const el = els[n - 1], myPdf = pdf, myScale = scales[n - 1];
    try {
      const page = await myPdf.getPage(n);
      if (rendered.get(n) !== tok) return;
      const vp = page.getViewport({ scale: myScale });
      const dpr = Math.max(1, Math.min(devicePixelRatio || 1, 2, 3000 / vp.width));
      const cv = document.createElement('canvas');
      cv.width = Math.floor(vp.width * dpr); cv.height = Math.floor(vp.height * dpr);
      cv.style.width = vp.width + 'px'; cv.style.height = vp.height + 'px';
      const task = page.render({ canvasContext: cv.getContext('2d'), viewport: vp, transform: dpr !== 1 ? [dpr, 0, 0, dpr, 0, 0] : null });
      tok.task = task;
      await task.promise;
      if (rendered.get(n) !== tok) return;
      const an = document.createElement('div'); an.className = 'annot';
      const tl = document.createElement('div'); tl.className = 'textLayer';
      tl.style.setProperty('--scale-factor', myScale);
      el.style.width = vp.width + 'px'; el.style.height = vp.height + 'px';
      el.replaceChildren(cv, an, tl);
      Annot.draw(n);
      const tc = await page.getTextContent();
      if (rendered.get(n) !== tok) return;
      pdfjsLib.renderTextLayer({ textContent: tc, textContentSource: tc, container: tl, viewport: vp, textDivs: [] });
    } catch (e) {
      if (!(e && e.name === 'RenderingCancelledException')) console.warn('render', n, e);
    }
  }

  function unrender(n) {
    const tok = rendered.get(n); if (!tok) return;
    try { tok.task && tok.task.cancel(); } catch (e) {}
    rendered.delete(n);
    els[n - 1] && els[n - 1].replaceChildren();
  }

  function curPos() {
    const y = host().scrollTop + TOP;
    let lo = 0, hi = els.length - 1;
    while (lo < hi) { const m = (lo + hi + 1) >> 1; if (els[m].offsetTop <= y + 4) lo = m; else hi = m - 1; }
    const el = els[lo], off = Math.min(1, Math.max(0, (y - el.offsetTop) / el.offsetHeight));
    const h = host();
    if (els.length > 1 && h.scrollTop + h.clientHeight >= h.scrollHeight - 6) return { page: els.length, off: Math.max(off, .5) };
    return { page: lo + 1, off };
  }

  function goTo(page, off = 0) {
    const el = els[page - 1]; if (!el) return;
    host().scrollTop = Math.max(0, el.offsetTop + off * el.offsetHeight - TOP);
  }

  function updateUI(p) {
    const n = sizes.length;
    $('#r-pg').textContent = `${num(p.page)} / ${num(n)}`;
    const pr = Math.min(100, Math.round((p.page - 1 + p.off) / n * 100));
    $('#r-pc').textContent = num(pr) + '%';
    $('#r-sub').textContent = `${t('page')} ${num(p.page)}`;
    $('#zv').textContent = num(Math.round(zoom * 100)) + '%';
    Annot.syncBm(p.page);
    placeThumb();
  }

  function placeThumb() {
    const h = host(), tr = $('#fscroll'), th = $('#fthumb');
    $('#fbub').textContent = `${num(curPos().page)} / ${num(sizes.length)}`;
    if (dragging) return;
    const max = h.scrollHeight - h.clientHeight;
    th.style.top = (max > 0 ? h.scrollTop / max : 0) * (tr.clientHeight - th.offsetHeight) + 'px';
  }

  function save() {
    if (!book || !pdf || !ready) return;
    const p = curPos(), n = sizes.length;
    book.lastPage = p.page; book.lastOffset = p.off; book.zoom = zoom;
    book.progress = (p.page === n && p.off > .35) ? 1 : Math.min(1, (p.page - 1 + p.off) / n);
    DB.put('books', book);
  }

  function onScroll() {
    if (!ready || raf) return;
    const fs = $('#fscroll'); fs.classList.add('act');
    clearTimeout(actT); actT = setTimeout(() => { if (!dragging) fs.classList.remove('act'); }, 1600);
    raf = requestAnimationFrame(() => {
      raf = 0;
      updateUI(curPos());
      clearTimeout(saveT); saveT = setTimeout(save, 450);
    });
  }

  function setZoom(z, mx, my) {
    z = Math.max(.7, Math.min(3, Math.round(z * 100) / 100));
    if (z === zoom || !pdf) return;
    const h = host();
    mx = mx ?? h.clientWidth / 2; my = my ?? h.clientHeight / 3;
    const r = z / zoom, ox = h.scrollLeft + mx, oy = h.scrollTop + my;
    ready = false; zoom = z;
    layout();
    h.scrollTop = oy * r - my; h.scrollLeft = ox * r - mx;
    ready = true; save(); updateUI(curPos());
  }

  function close() {
    if (!active) return;
    clearTimeout(saveT); save();
    active = false; ready = false;
    if (io) io.disconnect();
    rendered.clear();
    try { pdf && pdf.destroy(); } catch (e) {}
    pdf = null; els = []; book = null;
    $('#pin').innerHTML = '';
    $('#v-reader').classList.remove('on');
    Annot.hideTb();
    Lib.render();
  }

  function syncIcons() {
    if (!book) return;
    $('#r-fav').style.color = book.fav ? 'var(--danger)' : '';
  }

  function menu() {
    const th = [['light', 't_light'], ['dark', 't_dark'], ['sepia', 't_sepia']];
    Sheet.open(`<div class="lbl" style="margin-top:0">${t('text_size')}</div>
      <div class="stp"><button id="z-m"><i class="ti ti-minus"></i></button><b id="z-v">${num(Math.round(zoom * 100))}%</b><button id="z-p"><i class="ti ti-plus"></i></button></div>
      <div class="lbl">${t('theme')}</div>
      <div class="seg2" id="th">${th.map(([k, l]) => `<button data-th="${k}" class="${S.theme === k ? 'on' : ''}">${t(l)}</button>`).join('')}</div>
      <div class="lbl">${t('goto')}</div>
      <div style="display:flex;gap:10px"><input class="tinput" id="gp" type="number" min="1" max="${sizes.length}" placeholder="1 – ${sizes.length}" inputmode="numeric"><button class="btn pri" id="gb" style="flex:0 0 80px">${t('go')}</button></div>
      <div style="height:8px"></div>${optHTML('list-details', t('book_notes'), 'bn')}`, b => {
      const zv = () => $('#z-v', b).textContent = num(Math.round(zoom * 100)) + '%';
      $('#z-m', b).onclick = () => { setZoom(zoom - .25); zv(); };
      $('#z-p', b).onclick = () => { setZoom(zoom + .25); zv(); };
      $('#th', b).onclick = e => {
        const k = e.target.closest('[data-th]'); if (!k) return;
        S.theme = k.dataset.th; saveSettings(); applyTheme();
        $$('#th button', b).forEach(x => x.classList.toggle('on', x === k));
      };
      $('#gb', b).onclick = () => {
        const v = parseInt($('#gp', b).value, 10);
        if (v >= 1 && v <= sizes.length) { Sheet.close(); goTo(v, 0); }
      };
      $('[data-id=bn]', b).onclick = () => { Sheet.close(); setTimeout(Annot.listSheet, 220); };
    });
  }

  function init() {
    const h = host();
    h.addEventListener('scroll', onScroll, { passive: true });
    $('#r-back').onclick = () => history.back();
    $('#r-menu').onclick = menu;
    $('#r-bm').onclick = () => Annot.toggleBm(curPos());
    $('#r-fav').onclick = async () => {
      if (!book) return; book.fav = !book.fav; syncIcons(); await DB.put('books', book);
    };
    $('.r-bot').onclick = menu;

    // Zoom buttons
    $('#zi').onclick = () => setZoom(zoom + .25);
    $('#zo').onclick = () => setZoom(zoom - .25);

    // Right-side scroll handle: appears while scrolling, hides itself; drag it to move through the book
    const th = $('#fthumb'), grip = $('#fgrip'), tr = $('#fscroll');
    let drag = false;
    const move = e => {
      const r = tr.getBoundingClientRect(), tH = th.offsetHeight;
      const y = Math.min(Math.max(e.clientY - r.top - tH / 2, 0), r.height - tH);
      th.style.top = y + 'px';
      h.scrollTop = y / (r.height - tH) * (h.scrollHeight - h.clientHeight);
      $('#fbub').textContent = `${num(curPos().page)} / ${num(sizes.length)}`;
    };
    grip.addEventListener('pointerdown', e => {
      drag = dragging = true; grip.setPointerCapture(e.pointerId);
      grip.classList.add('drag'); e.preventDefault(); move(e);
    });
    grip.addEventListener('pointermove', e => { if (drag) move(e); });
    const stop = () => {
      if (!drag) return;
      drag = dragging = false; grip.classList.remove('drag'); placeThumb();
      clearTimeout(actT); actT = setTimeout(() => tr.classList.remove('act'), 1600);
    };
    grip.addEventListener('pointerup', stop);
    grip.addEventListener('pointercancel', stop);

    // Tap: toggle bars, or open an annotation under the finger
    h.addEventListener('click', e => {
      const sel = getSelection();
      if (sel && !sel.isCollapsed) return;
      const pg = e.target.closest('.page');
      if (pg && Annot.tap(+pg.dataset.n, e, pg)) return;
      $('#v-reader').classList.toggle('hide-ui');
    });

    // Pinch to zoom
    let pin = null;
    const dist = t => Math.hypot(t[0].clientX - t[1].clientX, t[0].clientY - t[1].clientY);
    h.addEventListener('touchstart', e => {
      if (e.touches.length === 2) {
        const r = h.getBoundingClientRect();
        pin = { d: dist(e.touches), z: zoom, r: 1,
          mx: (e.touches[0].clientX + e.touches[1].clientX) / 2 - r.left, my: (e.touches[0].clientY + e.touches[1].clientY) / 2 - r.top };
      }
    }, { passive: true });
    h.addEventListener('touchmove', e => {
      if (pin && e.touches.length === 2) {
        e.preventDefault();
        pin.r = Math.max(.4, Math.min(4, dist(e.touches) / pin.d));
        const p = $('#pin');
        p.style.transformOrigin = `${h.scrollLeft + pin.mx}px ${h.scrollTop + pin.my}px`;
        p.style.transform = `scale(${pin.r})`;
      }
    }, { passive: false });
    const end = () => {
      if (!pin) return;
      const p = pin; pin = null;
      $('#pin').style.transform = ''; $('#pin').style.transformOrigin = '';
      setZoom(p.z * p.r, p.mx, p.my);
    };
    h.addEventListener('touchend', e => { if (e.touches.length < 2) end(); });
    h.addEventListener('touchcancel', end);

    // Save position whenever the app goes to background
    document.addEventListener('visibilitychange', () => { if (document.hidden) { clearTimeout(saveT); save(); } });
    window.addEventListener('pagehide', save);
  }

  return {
    init, open, close, goTo, curPos, save, syncIcons,
    active: () => active, bookId: () => book && book.id, el: n => els[n - 1],
    visiblePages: () => [...rendered.keys()].map(n => ({ n, rect: els[n - 1].getBoundingClientRect() }))
  };
})();
