/* Hide folders / single books from the library */
const Hide = (() => {
  const ROOTS = ['/storage/emulated/0/', '/sdcard/'];
  const dirOf = p => p.slice(0, p.lastIndexOf('/'));
  const rel = d => { for (const r of ROOTS) if ((d + '/').startsWith(r)) return d.slice(r.length) || '/'; return d; };
  const folderName = d => rel(d).split('/').filter(Boolean).pop() || d;
  const hiddenBy = d => (S.hiddenFolders || []).find(h => d === h || d.startsWith(h + '/'));
  const hiddenBooks = () => Data.books.filter(b => b.hidden);
  const count = () => (S.hiddenFolders || []).length + hiddenBooks().length;

  const refresh = () => { saveSettings(); Lib.render(); Notes.render(); Settings.render(); };

  function hideFolder(d) {
    if (hiddenBy(d)) return;
    S.hiddenFolders = (S.hiddenFolders || []).filter(h => !h.startsWith(d + '/')).concat(d);
    refresh();
  }
  function showFolder(d) { S.hiddenFolders = (S.hiddenFolders || []).filter(h => h !== d); refresh(); }
  async function showBook(id) {
    const b = Data.books.find(x => x.id === id); if (!b) return;
    b.hidden = false; await DB.put('books', b); refresh();
  }

  /* ---- pick folders to hide ---- */
  async function folderSheet() {
    Sheet.open(`<h3 class="sh-t">${t('pick_t')}</h3><p class="sh-d">${t('pick_d')}</p><div id="hf-body"><p class="sh-d"><i class="ti ti-loader-2 spin"></i></p></div>`);
    const dirs = new Map();
    try { (await Auto.folders()).forEach((n, d) => dirs.set(d, n)); } catch (e) {}
    // folders of books already in the library, and folders already hidden
    Data.books.forEach(b => { if (b.src) { const d = dirOf(b.src); if (!dirs.has(d)) dirs.set(d, Data.books.filter(x => x.src && dirOf(x.src) === d).length); } });
    (S.hiddenFolders || []).forEach(d => { if (!dirs.has(d)) dirs.set(d, 0); });
    const body = $('#hf-body'); if (!body) return;
    const rows = [...dirs.keys()].sort((a, b) => rel(a).localeCompare(rel(b)));
    if (!rows.length) { body.innerHTML = `<p class="sh-d">${t('no_folders')}</p>`; return; }
    const paint = () => {
      body.innerHTML = rows.map(d => {
        const own = (S.hiddenFolders || []).includes(d), by = hiddenBy(d);
        return `<button class="opt" data-d="${esc(d)}" style="align-items:flex-start">
          <i class="ti ti-${by ? 'folder-off' : 'folder'}" style="color:${by ? 'var(--danger)' : 'inherit'};margin-top:2px"></i>
          <span style="flex:1;min-width:0"><span style="display:block;font-size:14px">${esc(folderName(d))}</span>
          <small style="color:var(--text2);word-break:break-all">${esc(rel(d))} · ${num(dirs.get(d))}${t('files_n')}${by && !own ? ' · ' + t('parent_hidden') : ''}</small></span>
          <span class="tgl ${by ? 'on' : ''}" style="pointer-events:none"></span></button>`;
      }).join('');
    };
    paint();
    body.onclick = e => {
      const o = e.target.closest('[data-d]'); if (!o) return;
      const d = o.dataset.d;
      if ((S.hiddenFolders || []).includes(d)) showFolder(d);
      else if (hiddenBy(d)) { toast(t('parent_hidden')); return; }
      else hideFolder(d);
      paint();
    };
  }

  /* ---- list of everything hidden, with "show" buttons ---- */
  function manageSheet() {
    const draw = () => {
      const fs = S.hiddenFolders || [], bs = hiddenBooks();
      const row = (icon, title, sub, attr) => `<div class="opt" style="cursor:default"><i class="ti ti-${icon}"></i>
        <span style="flex:1;min-width:0"><span style="display:block;font-size:14px">${esc(title)}</span><small style="color:var(--text2);word-break:break-all">${esc(sub)}</small></span>
        <button class="btn" ${attr} style="flex:none;height:36px;padding:0 14px">${t('unhide')}</button></div>`;
      $('#hm-body').innerHTML = (fs.length || bs.length) ? (fs.length ? `<div class="lbl">${t('hidden_folders')}</div>` + fs.map(d => row('folder-off', folderName(d), rel(d), `data-unf="${esc(d)}"`)).join('') : '') +
        (bs.length ? `<div class="lbl">${t('hidden_books')}</div>` + bs.map(b => row('file-off', b.title, b.src ? rel(dirOf(b.src)) : '', `data-unb="${b.id}"`)).join('') : '')
        : `<p class="sh-d">${t('nothing_hidden')}</p>`;
    };
    Sheet.open(`<h3 class="sh-t">${t('hide_list')}</h3><div id="hm-body"></div>`, b => {
      draw();
      b.onclick = e => {
        const f = e.target.closest('[data-unf]'), k = e.target.closest('[data-unb]');
        if (f) { showFolder(f.dataset.unf); draw(); }
        else if (k) { showBook(k.dataset.unb).then(draw); }
      };
    });
  }

  return { hideFolder, showFolder, folderSheet, manageSheet, count, dirOf, folderName };
})();
