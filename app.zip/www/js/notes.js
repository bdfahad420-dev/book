const Notes = (() => {
  let f = 'all';
  const bookOf = id => Data.books.find(b => b.id === id);

  function item(a) {
    const b = bookOf(a.bookId);
    const body = a.type === 'bm'
      ? `<div class="nt"><i class="ti ti-bookmark" style="font-size:17px;vertical-align:-3px;color:${a.color}"></i> ${t('bm')}</div>`
      : `<div class="nt"><span class="${a.type === 'ul' ? 'ult' : 'hlt'}" style="${a.type === 'ul' ? 'border-color:' + a.color : 'background:' + a.color}">${esc(a.text)}</span></div>`;
    return `<div class="nitem" data-id="${a.id}"><span class="nb" style="background:${a.color}"></span>
      <div class="grow">${body}${a.note ? `<div class="nn"><i class="ti ti-note" style="font-size:15px;margin-top:3px"></i><span>${esc(a.note)}</span></div>` : ''}
      <div class="nm">${esc(b ? b.title : '')} · ${t('page')} ${num(a.page)}</div></div>
      <button class="x" data-del aria-label="delete"><i class="ti ti-trash"></i></button></div>`;
  }

  function render() {
    const all = Data.annots.slice().sort((a, b) => b.created - a.created);
    const l = all.filter(a => f === 'all' || a.type === f);
    $('#note-cnt').textContent = all.length ? num(all.length) + t('items') : '';
    $('#n-chips').innerHTML = [['all', 'all_types'], ['hl', 'hl'], ['ul', 'ul'], ['bm', 't_bm']]
      .map(([k, lb]) => `<button class="chip ${f === k ? 'on' : ''}" data-f="${k}">${t(lb)}</button>`).join('');
    $('#n-list').innerHTML = l.length ? l.map(item).join('')
      : `<div class="empty"><i class="ti ti-highlight"></i><h3>${t('empty_n')}</h3><p>${t('empty_nd')}</p></div>`;
  }

  function init() {
    $('#n-chips').addEventListener('click', e => { const c = e.target.closest('[data-f]'); if (c) { f = c.dataset.f; render(); } });
    $('#n-list').addEventListener('click', async e => {
      const it = e.target.closest('.nitem'); if (!it) return;
      const a = Data.annots.find(x => x.id === it.dataset.id); if (!a) return;
      if (e.target.closest('[data-del]')) {
        if (await ask(t('del_note_q'), '', t('del'))) {
          Data.annots = Data.annots.filter(x => x !== a);
          await DB.del('annots', a.id); render(); Lib.render();
        }
        return;
      }
      App.openBook(a.bookId, { page: a.page, off: Math.max(0, (a.y || 0) - .02) });
    });
  }
  return { init, render };
})();

const Settings = (() => {
  function palette(sel, listKey, curKey) {
    const el = $(sel); let lp = 0, fired = false;
    const cancel = () => clearTimeout(lp);
    el.oncontextmenu = e => e.preventDefault();
    el.onpointerdown = e => {
      const d = e.target.closest('[data-c]'); fired = false; if (!d) return;
      lp = setTimeout(async () => {
        fired = true;
        if (S[listKey].length <= 1) return;
        if (await ask(t('rm_color_q'), '', t('del'))) {
          S[listKey] = S[listKey].filter(c => c !== d.dataset.c);
          if (S[curKey] === d.dataset.c) S[curKey] = S[listKey][0];
          saveSettings(); render(); Annot.renderDots();
        }
      }, 600);
    };
    el.onpointerup = el.onpointerleave = el.onpointercancel = cancel;
    el.onclick = async e => {
      if (fired) { fired = false; return; }
      const d = e.target.closest('[data-c]');
      if (d) { S[curKey] = d.dataset.c; saveSettings(); render(); return; }
      if (e.target.closest('[data-add]')) {
        const c = await pickColor();
        if (c) { if (!S[listKey].includes(c)) S[listKey].push(c); S[curKey] = c; saveSettings(); render(); Annot.renderDots(); }
      }
    };
  }

  function render() {
    const th = [['light', 't_light'], ['dark', 't_dark'], ['sepia', 't_sepia']];
    $('#set-body').innerHTML = `
      <div class="card2"><h4>${t('language')}</h4><div class="seg2" id="s-lang">
        <button data-l="bn" class="${S.lang === 'bn' ? 'on' : ''}">বাংলা</button><button data-l="en" class="${S.lang === 'en' ? 'on' : ''}">English</button></div></div>
      <div class="card2"><h4>${t('theme')}</h4><div class="seg2" id="s-th">
        ${th.map(([k, l]) => `<button data-th="${k}" class="${S.theme === k ? 'on' : ''}">${t(l)}</button>`).join('')}</div></div>
      <div class="card2"><h4>${t('hl_colors')}</h4><p>${t('colors_hint')}</p><div class="sw" id="s-hl">${swatchesHTML(S.hlColors, S.hlColor)}</div></div>
      <div class="card2"><h4>${t('ul_colors')}</h4><p>${t('colors_hint')}</p><div class="sw" id="s-ul">${swatchesHTML(S.ulColors, S.ulColor)}</div>
        <div class="prev">${t('preview')}: <span class="hlp" style="background:${S.hlColor};color:#2c2c2a">${t('sample_hl')}</span> · <span class="ulp" style="border-color:${S.ulColor}">${t('sample_ul')}</span></div></div>
      ${Auto.available() ? `<div class="card2"><div style="display:flex;align-items:center;gap:14px"><div class="grow"><h4>${t('auto_t')}</h4><p style="margin:0">${t('auto_d')}</p></div><button class="tgl ${S.auto ? 'on' : ''}" id="s-auto" aria-label="auto"></button></div>
        <p id="s-perm" style="margin:10px 0 0"></p>
        <div class="btns"><button class="btn" id="s-grant" style="display:none"><i class="ti ti-lock-open"></i> ${t('perm_go')}</button>${S.auto ? `<button class="btn" id="s-scan"><i class="ti ti-refresh"></i> ${t('auto_scan')}</button>` : ''}</div></div>` : ''}
      <div class="card2"><h4>${t('about')}</h4><p style="margin:0">${t('about_d')}</p></div>`;
    palette('#s-hl', 'hlColors', 'hlColor');
    palette('#s-ul', 'ulColors', 'ulColor');
    const ta = $('#s-auto'); if (ta) ta.onclick = () => S.auto ? Auto.disable() : Auto.enable();
    if (Auto.available()) Auto.granted().then(g => {
      const pe = $('#s-perm'), gb = $('#s-grant'); if (!pe) return;
      pe.textContent = g ? t('perm_ok') : t('perm_no');
      pe.style.color = g ? 'var(--accent)' : 'var(--danger)';
      if (!g && gb) { gb.style.display = ''; gb.onclick = () => Auto.requestAccess(); }
    });
    const sc = $('#s-scan'); if (sc) sc.onclick = async () => { const n = await Auto.scan(); if (!n) toast(t('auto_none')); };
    $('#s-lang').onclick = e => {
      const b = e.target.closest('[data-l]'); if (!b) return;
      S.lang = b.dataset.l; saveSettings(); applyLang(); App.renderAll();
    };
    $('#s-th').onclick = e => {
      const b = e.target.closest('[data-th]'); if (!b) return;
      S.theme = b.dataset.th; saveSettings(); applyTheme(); render();
    };
  }
  return { render };
})();
