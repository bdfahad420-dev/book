#!/usr/bin/env bash
set -euo pipefail

retry() {  # retry <times> <command...>  (network hiccups on CI are common)
  local n=$1; shift; local i
  for i in $(seq 1 "$n"); do
    "$@" && return 0
    echo "[retry $i/$n failed] $*"; sleep $((i * 10))
  done
  return 1
}

retry 4 npm install --no-audit --no-fund

# Libraries needed at runtime (copied from node_modules into www/lib)
mkdir -p www/lib/fonts
cp node_modules/pdfjs-dist/build/pdf.min.js www/lib/
cp node_modules/pdfjs-dist/build/pdf.worker.min.js www/lib/
cp -r node_modules/pdfjs-dist/standard_fonts www/lib/ 2>/dev/null || true
cp -r node_modules/pdfjs-dist/cmaps www/lib/ 2>/dev/null || true

for f in www/lib/pdf.min.js www/lib/pdf.worker.min.js; do
  [ -s "$f" ] || { echo "ERROR: $f missing - pdf.js was not copied"; exit 1; }
done

CSS=$(find node_modules/@tabler/icons-webfont -name 'tabler-icons.min.css' | head -1)
FONTS=$(find node_modules/@tabler/icons-webfont -type d -name fonts | head -1)
cp "$CSS" www/lib/
cp "$FONTS"/* www/lib/fonts/

# Android project
[ -d android ] || retry 3 npx cap add android
retry 3 npx cap sync android

# Native file-access plugin + permissions (auto-import PDFs from Downloads)
PKG_DIR=android/app/src/main/java/com/boighor/reader
mkdir -p "$PKG_DIR"
cp native/FilesPlugin.java native/MainActivity.java "$PKG_DIR/"
MANIFEST=android/app/src/main/AndroidManifest.xml
if ! grep -q MANAGE_EXTERNAL_STORAGE "$MANIFEST"; then
  sed -i 's#</manifest>#    <uses-permission android:name="android.permission.MANAGE_EXTERNAL_STORAGE" />\n    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />\n</manifest>#' "$MANIFEST"
fi

grep -q MANAGE_EXTERNAL_STORAGE "$MANIFEST" || { echo "ERROR: permission not added to manifest"; exit 1; }
ls "$PKG_DIR"/FilesPlugin.java "$PKG_DIR"/MainActivity.java

# App icon (optional)
if [ -d resources/android ]; then
  cp -r resources/android/res/* android/app/src/main/res/
fi

cd android
chmod +x gradlew

# Download Gradle ourselves from several mirrors (github.com sometimes answers 504),
# then point the wrapper at the local copy.
PROPS=gradle/wrapper/gradle-wrapper.properties
GV=$(sed -n 's#.*gradle-\([0-9][0-9.]*\)-[a-z]*\.zip.*#\1#p' "$PROPS" | head -1)
echo "Gradle version: $GV"
GZIP="$RUNNER_TEMP/gradle-$GV-bin.zip"; [ -n "${RUNNER_TEMP:-}" ] || GZIP="/tmp/gradle-$GV-bin.zip"
got=0
for url in \
  "https://services.gradle.org/distributions/gradle-$GV-bin.zip" \
  "https://downloads.gradle.org/distributions/gradle-$GV-bin.zip" \
  "https://mirrors.cloud.tencent.com/gradle/gradle-$GV-bin.zip" \
  "https://mirrors.aliyun.com/gradle/gradle-$GV-bin.zip"; do
  echo "Downloading $url"
  if curl -fsSL --retry 3 --retry-all-errors --connect-timeout 20 -o "$GZIP" "$url" && unzip -tq "$GZIP" >/dev/null 2>&1; then got=1; break; fi
  rm -f "$GZIP"
done
if [ "$got" = 1 ]; then
  grep -v -e '^distributionUrl=' -e '^distributionSha256Sum=' "$PROPS" > "$PROPS.new"
  echo "distributionUrl=file\\:$GZIP" >> "$PROPS.new"
  mv "$PROPS.new" "$PROPS"
  echo "Using local Gradle: $GZIP"
else
  echo "Could not pre-download Gradle; the wrapper will try by itself"
fi

ok=0
for i in 1 2 3; do
  if ./gradlew assembleDebug --no-daemon --stacktrace; then ok=1; break; fi
  echo "Gradle attempt $i failed, retrying in 20s..."; sleep 20
done
if [ "$ok" != 1 ] && command -v gradle >/dev/null 2>&1; then
  echo "Falling back to the Gradle installed on the runner"
  gradle assembleDebug --no-daemon && ok=1
fi
[ "$ok" = 1 ] || { echo "ERROR: Gradle build failed after retries"; exit 1; }
cd ..

[ -s android/app/build/outputs/apk/debug/app-debug.apk ] || { echo 'ERROR: APK not produced'; exit 1; }
cp android/app/build/outputs/apk/debug/app-debug.apk Boighor.apk
ls -la Boighor.apk
