#!/usr/bin/env bash
set -euo pipefail

npm install --no-audit --no-fund

# Libraries needed at runtime (copied from node_modules into www/lib)
mkdir -p www/lib/fonts
cp node_modules/pdfjs-dist/build/pdf.min.js www/lib/
cp node_modules/pdfjs-dist/build/pdf.worker.min.js www/lib/
cp -r node_modules/pdfjs-dist/standard_fonts www/lib/ 2>/dev/null || true
cp -r node_modules/pdfjs-dist/cmaps www/lib/ 2>/dev/null || true

CSS=$(find node_modules/@tabler/icons-webfont -name 'tabler-icons.min.css' | head -1)
FONTS=$(find node_modules/@tabler/icons-webfont -type d -name fonts | head -1)
cp "$CSS" www/lib/
cp "$FONTS"/* www/lib/fonts/

# Android project
[ -d android ] || npx cap add android
npx cap sync android

# Native file-access plugin + permissions (auto-import PDFs from Downloads)
PKG_DIR=android/app/src/main/java/com/boighor/reader
mkdir -p "$PKG_DIR"
cp native/FilesPlugin.java native/MainActivity.java "$PKG_DIR/"
MANIFEST=android/app/src/main/AndroidManifest.xml
if ! grep -q MANAGE_EXTERNAL_STORAGE "$MANIFEST"; then
  sed -i 's#</manifest>#    <uses-permission android:name="android.permission.MANAGE_EXTERNAL_STORAGE" />\n    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />\n</manifest>#' "$MANIFEST"
fi

# App icon (optional)
if [ -d resources/android ]; then
  cp -r resources/android/res/* android/app/src/main/res/
fi

cd android
chmod +x gradlew
./gradlew assembleDebug --no-daemon
cd ..

cp android/app/build/outputs/apk/debug/app-debug.apk Boighor.apk
ls -la Boighor.apk
