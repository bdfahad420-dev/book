package com.boighor.reader;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.File;

@CapacitorPlugin(name = "BoighorFiles")
public class FilesPlugin extends Plugin {

    private boolean granted() {
        if (Build.VERSION.SDK_INT >= 30) {
            return Environment.isExternalStorageManager();
        }
        return ContextCompat.checkSelfPermission(getContext(), Manifest.permission.READ_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED;
    }

    @PluginMethod
    public void status(PluginCall call) {
        JSObject r = new JSObject();
        r.put("granted", granted());
        call.resolve(r);
    }

    @PluginMethod
    public void requestAccess(PluginCall call) {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                try {
                    Intent i = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                            Uri.parse("package:" + getContext().getPackageName()));
                    getActivity().startActivity(i);
                } catch (Exception first) {
                    // some phones lack the per-app screen: open the general list instead
                    getActivity().startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
                }
            } else {
                ActivityCompat.requestPermissions(getActivity(),
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 9001);
            }
            call.resolve();
        } catch (Exception e) {
            call.reject(String.valueOf(e.getMessage()));
        }
    }

    private static final int MAX_DEPTH = 8;
    private static final int MAX_FILES = 3000;

    @PluginMethod
    public void listPdfs(PluginCall call) {
        JSArray out = new JSArray();
        JSObject r = new JSObject();
        boolean ok = granted();
        if (ok) {
            // scan the whole shared storage (Download, Documents, Telegram, WhatsApp, SD card folders...)
            walk(Environment.getExternalStorageDirectory(), 0, out, new int[]{0});
        }
        r.put("granted", ok);
        r.put("files", out);
        call.resolve(r);
    }

    private void walk(File dir, int depth, JSArray out, int[] count) {
        File[] list = dir.listFiles();
        if (list == null) return;
        for (File f : list) {
            if (count[0] >= MAX_FILES) return;
            String n = f.getName();
            if (n.startsWith(".")) continue;
            if (f.isDirectory()) {
                // Android/data and Android/obb are private app folders; only Android/media holds shared files
                if (depth == 0 && n.equals("Android")) {
                    File media = new File(f, "media");
                    if (media.isDirectory()) walk(media, depth + 2, out, count);
                    continue;
                }
                if (depth < MAX_DEPTH) walk(f, depth + 1, out, count);
            } else if (n.toLowerCase().endsWith(".pdf") && f.length() > 0) {
                JSObject o = new JSObject();
                o.put("path", f.getAbsolutePath());
                o.put("name", n);
                o.put("size", f.length());
                o.put("mtime", f.lastModified());
                out.put(o);
                count[0]++;
            }
        }
    }
}
