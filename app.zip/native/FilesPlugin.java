package com.boighor.reader;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.File;

@CapacitorPlugin(name = "BoighorFiles")
public class FilesPlugin extends Plugin {

    private boolean granted() {
        if (Build.VERSION.SDK_INT >= 30) {
            return Environment.isExternalStorageManager();
        }
        return ContextCompat.checkSelfPermission(getContext(), Manifest.permission.READ_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED;
    }

    @PluginMethod
    public void status(PluginCall call) {
        JSObject r = new JSObject();
        r.put("granted", granted());
        call.resolve(r);
    }

    @PluginMethod
    public void requestAccess(PluginCall call) {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                Intent i = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:" + getContext().getPackageName()));
                getActivity().startActivity(i);
            } else {
                ActivityCompat.requestPermissions(getActivity(),
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 9001);
            }
            call.resolve();
        } catch (Exception e) {
            call.reject(String.valueOf(e.getMessage()));
        }
    }

    @PluginMethod
    public void listPdfs(PluginCall call) {
        JSArray out = new JSArray();
        JSObject r = new JSObject();
        boolean ok = granted();
        if (ok) {
            File root = Environment.getExternalStorageDirectory();
            String[] dirs = {"Download", "Documents", "Books", "Telegram", "WhatsApp"};
            for (String d : dirs) {
                File f = new File(root, d);
                if (f.isDirectory()) walk(f, 0, out);
            }
        }
        r.put("granted", ok);
        r.put("files", out);
        call.resolve(r);
    }

    private void walk(File dir, int depth, JSArray out) {
        File[] list = dir.listFiles();
        if (list == null) return;
        for (File f : list) {
            String n = f.getName();
            if (n.startsWith(".")) continue;
            if (f.isDirectory()) {
                if (depth < 3) walk(f, depth + 1, out);
            } else if (n.toLowerCase().endsWith(".pdf") && f.length() > 0) {
                JSObject o = new JSObject();
                o.put("path", f.getAbsolutePath());
                o.put("name", n);
                o.put("size", f.length());
                o.put("mtime", f.lastModified());
                out.put(o);
            }
        }
    }
}
